// POST or CREATE Request 
fetch('http://localhost:3000/students', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
    // 'Authorization': 'Bearer YOUR_TOKEN' // Add if API requires a token
  },
  body: JSON.stringify({
    "id": "2",
    "name": "Bob Smith",
    "email": "bob@university.edu",
    "major": "Business",
    "gpa": 3.2,
    "enrolled": true
  })
})
.then(response => {
  if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
  return response.json();
})
.then(data => console.log('Success:', data))
.catch(error => console.error('Error:', error));

// PUT or UPDATE Request
fetch('http://localhost:3000/students/1', {
  method: 'PUT',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    gpa: '3.9',
    status: 'updated'
  })
})
.then(response => response.json())
.then(data => console.log('Success:', data))
.catch(error => console.error('Error:', error));

// DELETE Request
fetch('http://localhost:3000/students/2', {
  method: 'DELETE',
  headers: {
    'Content-Type': 'application/json'
    // Include authentication headers here if needed, e.g.:
    // 'Authorization': 'Bearer YOUR_TOKEN'
  }
})
.then(response => {
  if (!response.ok) {
    throw new Error(`HTTP error! Status: ${response.status}`);
  }
  // DELETE requests often return a 204 No Content (empty response)
  return response.status === 204 ? null : response.json();
})
.then(data => console.log('Deleted successfully:', data))
.catch(error => console.error('Error executing delete:', error));

